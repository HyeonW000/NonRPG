#include "UI/InventoryWidget.h"
#include "UI/InventorySlotWidget.h"
#include "Core/BPC_UIManager.h"
#include "Inventory/InventoryComponent.h"
#include "Inventory/InventoryItem.h"
#include "Equipment/EquipmentComponent.h"
#include "Inventory/ItemDragDropOperation.h"
#include "Components/UniformGridPanel.h"
#include "Components/UniformGridSlot.h"
#include "Blueprint/WidgetTree.h"

void UInventoryWidget::NativeConstruct()
{
    Super::NativeConstruct();

    // �̹� InvRef�� ���õǾ� �ְ� ������ ���� ���ٸ� �ʱ�ȭ
    if (InvRef && Slots.Num() == 0)
    {
        BindDelegates();
        InitSlots();
        RefreshAll();
    }
}

void UInventoryWidget::NativeDestruct()
{
    UnbindDelegates();
    ClearSlots();
    Super::NativeDestruct();
}

void UInventoryWidget::SetInventory(UInventoryComponent* InInventory)
{
    if (InvRef == InInventory)
    {
        return;
    }

    UnbindDelegates();
    InvRef = InInventory;

    ClearSlots();

    if (InvRef)
    {
        BindDelegates();
        InitSlots();
        RefreshAll();
    }
}

void UInventoryWidget::BindDelegates()
{
    if (!InvRef) return;

    // InventoryComponent.h �� ����� ��������Ʈ ����̳ʺ� ��������Ʈ:
    // UPROPERTY(BlueprintAssignable) FOnInventorySlotUpdated OnSlotUpdated;
    // UPROPERTY(BlueprintAssignable) FOnInventoryRefreshed   OnInventoryRefreshed;
    InvRef->OnSlotUpdated.AddDynamic(this, &UInventoryWidget::HandleSlotUpdated);
    InvRef->OnInventoryRefreshed.AddDynamic(this, &UInventoryWidget::HandleInventoryRefreshed);
}

void UInventoryWidget::UnbindDelegates()
{
    if (!InvRef) return;
    InvRef->OnSlotUpdated.RemoveAll(this);
    InvRef->OnInventoryRefreshed.RemoveAll(this);
}

void UInventoryWidget::InitSlots()
{
    if (!Grid)
    {
        UE_LOG(LogTemp, Warning, TEXT("[InventoryWidget] Grid is null (BindWidget name mismatch?)."));
        return;
    }
    if (!SlotWidgetClass)
    {
        UE_LOG(LogTemp, Warning, TEXT("[InventoryWidget] SlotWidgetClass is not set."));
        return;
    }

    ClearSlots();

    const int32 Count = InvRef ? InvRef->GetSlotCount() : 0;
    if (Count <= 0) return;

    Slots.SetNum(Count);

    for (int32 Index = 0; Index < Count; ++Index)
    {
        UInventorySlotWidget* SlotWidget = CreateWidget<UInventorySlotWidget>(this, SlotWidgetClass);
        if (!SlotWidget) continue;

        // ���⼭ �� �ٷ� �ʱ�ȭ + ��������Ʈ ���ε����� ó��
        SlotWidget->InitSlot(InvRef, Index);

        const int32 Row = Columns > 0 ? Index / Columns : 0;
        const int32 Col = Columns > 0 ? Index % Columns : Index;

        if (UUniformGridSlot* GridSlot = Grid->AddChildToUniformGrid(SlotWidget, Row, Col))
        {
            // �ʿ� �� ����/�е� �� �߰� ����
            // GridSlot->SetHorizontalAlignment(HAlign_Fill);
            // GridSlot->SetVerticalAlignment(VAlign_Fill);
        }

        // ���⼭�� 'SlotWidget' �� �����ؾ� ��
        Slots[Index] = SlotWidget;
    }

    InvalidateLayoutAndVolatility();
    ForceLayoutPrepass();
}

void UInventoryWidget::InitInventoryUI(UInventoryComponent* InInventory, UEquipmentComponent* InEquipment)
{
    OwnerInventory = InInventory;
    OwnerEquipment = InEquipment;

    // �ٽ�: SetInventory�� ���ο��� ��������Ʈ ���ε� �� ���� ����(InitSlots) �� ��ü ���ű��� ó��
    SetInventory(InInventory);

    UE_LOG(LogTemp, Warning, TEXT("[InvUI] InitInventoryUI -> Inv=%s, Eq=%s, BuiltSlots=%d"),
        *GetNameSafe(InInventory), *GetNameSafe(InEquipment), Slots.Num());
}


void UInventoryWidget::ClearSlots()
{
    if (Grid)
    {
        Grid->ClearChildren();
    }
    Slots.Empty();
}

void UInventoryWidget::RefreshAll()
{
    for (int32 i = 0; i < Slots.Num(); ++i)
    {
        if (UInventorySlotWidget* S = Slots[i])
        {
            // ���� ������ ���� ���� ��ƾ(RefreshFromInventory)�� ȣ��
            S->RefreshFromInventory();
        }
    }
}

void UInventoryWidget::HandleSlotUpdated(int32 Index, UInventoryItem* /*Item*/)
{
    if (!Slots.IsValidIndex(Index)) return;
    if (UInventorySlotWidget* S = Slots[Index])
    {
        S->RefreshFromInventory();
    }
}

void UInventoryWidget::HandleInventoryRefreshed()
{
    RefreshAll();
}

bool UInventoryWidget::NativeOnDragOver(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent,
    UDragDropOperation* InOperation)
{
    // ��񿡼� ������ �巡�׸� â ��򰡿� ��� ����
    if (const UItemDragDropOperation* Op = Cast<UItemDragDropOperation>(InOperation))
    {
        if (Op->bFromEquipment)
        {
            return true; // ��� ���� OK
        }
    }
    return Super::NativeOnDragOver(InGeometry, InDragDropEvent, InOperation);
}

bool UInventoryWidget::NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent,
    UDragDropOperation* InOperation)
{
    const UItemDragDropOperation* Op = Cast<UItemDragDropOperation>(InOperation);
    if (!Op || !OwnerEquipment)
    {
        return Super::NativeOnDrop(InGeometry, InDragDropEvent, InOperation);
    }

    // ��񽽷Կ��� ������ ��� �� ���� �����ؼ� �κ��丮��
    if (Op->bFromEquipment && Op->FromEquipSlot != EEquipmentSlot::None)
    {
        int32 OutIndex = INDEX_NONE;
        const bool bOk = OwnerEquipment->UnequipToInventory(Op->FromEquipSlot, OutIndex);
        if (bOk)
        {
            RefreshAll(); // �κ��丮 ���Ե� ���ΰ�ħ

            // �� ĳ����â ��� ���Ե� ��� ����
            if (APlayerController* PC = GetWorld()->GetFirstPlayerController())
            {
                // UIManager ã�Ƽ� ȣ��
                UBPC_UIManager* UI = nullptr;

                // OwnerEquipment ������ �� ������Ʈ���� ���� ã�ƺ���
                if (AActor* OwnerActor = OwnerEquipment->GetOwner())
                {
                    UI = OwnerActor->FindComponentByClass<UBPC_UIManager>();
                }
                // �� ã���� Pawn/Controller ����
                if (!UI)
                {
                    if (APawn* Pawn = PC->GetPawn())
                        UI = Pawn->FindComponentByClass<UBPC_UIManager>();
                    if (!UI)
                        UI = PC->FindComponentByClass<UBPC_UIManager>();
                }

                if (UI)
                {
                    UI->RefreshCharacterEquipmentUI(); // ���ο��� CharacterWindow->RefreshAllSlots()
                }
            }

            return true;
        }
        return false;
    }

    return Super::NativeOnDrop(InGeometry, InDragDropEvent, InOperation);
}