#include "UI/UIViewportUtils.h"
#include "Engine/Engine.h"
#include "Engine/GameViewportClient.h"
#include "Engine/LocalPlayer.h"
#include "Widgets/SViewport.h"
#include "Widgets/SWidget.h"

namespace UIViewportUtils
{
    TSharedPtr<SViewport> GetGameViewportSViewport(UWorld* World)
    {
        if (!World) return nullptr;

        UGameViewportClient* GVC = nullptr;

        // 1) �켱 ���� ������ ���� �÷��̾�� ViewportClient�� ���
        if (ULocalPlayer* LP = World->GetFirstLocalPlayerFromController())
        {
            GVC = LP->ViewportClient;
        }

        // 2) �����ϸ� ���� GEngine�� GameViewport�� ����
        if (!GVC && GEngine)
        {
            GVC = GEngine->GameViewport;
        }

        if (!GVC) return nullptr;

        // UE5.5: GetGameViewportWidget()�� TSharedPtr<SWidget> ��ȯ
        TSharedPtr<SWidget> W = GVC->GetGameViewportWidget();
        if (!W.IsValid()) return nullptr;

        // �밳 SViewport�̹Ƿ� ĳ���� �õ�
        TSharedPtr<SViewport> SV = StaticCastSharedPtr<SViewport>(W);
        return SV;
    }
}

bool UIViewportUtils::GetGameViewportPixelSize(UWorld* World, FVector2D& OutPixelSize)
{
    OutPixelSize = FVector2D::ZeroVector;

    if (!World) return false;

    UGameViewportClient* GVC = nullptr;
    if (ULocalPlayer* LP = World->GetFirstLocalPlayerFromController())
    {
        GVC = LP->ViewportClient;
    }
    if (!GVC && GEngine)
    {
        GVC = GEngine->GameViewport;
    }
    if (!GVC || !GVC->Viewport) return false;

    const FIntPoint P = GVC->Viewport->GetSizeXY();
    OutPixelSize = FVector2D((float)P.X, (float)P.Y);
    return (P.X > 0 && P.Y > 0);
}