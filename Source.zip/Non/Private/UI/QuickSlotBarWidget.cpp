#include "UI/QuickSlotBarWidget.h"
#include "UI/QuickSlotSlotWidget.h"
#include "UI/QuickSlotManager.h"
#include "Inventory/InventoryItem.h"
#include "TimerManager.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/Pawn.h"
#include "Character/NonCharacterBase.h" 

void UQuickSlotBarWidget::NativeConstruct()
{
    Super::NativeConstruct();

    RetryCount = 0;
    // ���� �ʱ�ȭ ����
    if (UWorld* W = GetWorld())
    {
        W->GetTimerManager().SetTimer(InitTimerHandle, this, &UQuickSlotBarWidget::TryInit, 0.05f, false);
    }
}

void UQuickSlotBarWidget::NativeDestruct()
{
    UnbindManagerDelegate();

    if (UWorld* W = GetWorld())
    {
        W->GetTimerManager().ClearTimer(InitTimerHandle);
    }
    Super::NativeDestruct();
}

void UQuickSlotBarWidget::TryInit()
{
    // 1) Owning Player �� Pawn �� Character
    APlayerController* PC = GetOwningPlayer();
    if (!PC)
    {
        // ��õ�
        if (++RetryCount < MaxRetries && GetWorld())
        {
            GetWorld()->GetTimerManager().SetTimer(InitTimerHandle, this, &UQuickSlotBarWidget::TryInit, 0.05f, false);
        }
        return;
    }

    APawn* Pawn = PC->GetPawn();
    ANonCharacterBase* Char = Pawn ? Cast<ANonCharacterBase>(Pawn) : nullptr;
    if (!Char)
    {
        if (++RetryCount < MaxRetries && GetWorld())
        {
            GetWorld()->GetTimerManager().SetTimer(InitTimerHandle, this, &UQuickSlotBarWidget::TryInit, 0.05f, false);
        }
        return;
    }

    // 2) QuickSlotManager Ȯ��
    UQuickSlotManager* Mgr = Char->GetQuickSlotManager();
    if (!IsValid(Mgr))
    {
        if (++RetryCount < MaxRetries && GetWorld())
        {
            GetWorld()->GetTimerManager().SetTimer(InitTimerHandle, this, &UQuickSlotBarWidget::TryInit, 0.05f, false);
        }
        return;
    }
    Manager = Mgr;

    // 3) ���� ����
    if (!CollectSlots() || Slots.Num() == 0)
    {
        // ������ ���� �������� �ʾ��� �� ���� �� ��õ�
        if (++RetryCount < MaxRetries && GetWorld())
        {
            GetWorld()->GetTimerManager().SetTimer(InitTimerHandle, this, &UQuickSlotBarWidget::TryInit, 0.05f, false);
        }
        return;
    }

    // 4) ���Կ� �Ŵ��� ����
    AssignManagerToSlots();

    // 5) �ʱ� ����ȭ(������/����)
    InitialRefresh();

    // 6) �̺�Ʈ ���ε�(������!)
    BindManagerDelegate();
}

bool UQuickSlotBarWidget::CollectSlots()
{
    Slots.Reset();

    auto PushIfValid = [this](UQuickSlotSlotWidget* In)
        {
            if (IsValid(In))
            {
                Slots.Add(In);
            }
        };

    PushIfValid(Slot_0); PushIfValid(Slot_1); PushIfValid(Slot_2); PushIfValid(Slot_3); PushIfValid(Slot_4);
    PushIfValid(Slot_5); PushIfValid(Slot_6); PushIfValid(Slot_7); PushIfValid(Slot_8); PushIfValid(Slot_9);

    // �ʿ��� ��ŭ�� ����(�����̳ʿ��� �Ϻ� ������ �� �� ���� ����)
    return true;
}

void UQuickSlotBarWidget::AssignManagerToSlots()
{
    if (!Manager.IsValid()) return;

    for (int32 i = 0; i < Slots.Num(); ++i)
    {
        if (UQuickSlotSlotWidget* S = Slots[i])
        {
            S->SetManager(Manager.Get());
            S->QuickIndex = i;          // �� ������ i�� �����
        }
    }
}

void UQuickSlotBarWidget::InitialRefresh()
{
    for (UQuickSlotSlotWidget* S : Slots)
    {
        if (IsValid(S))
        {
            S->Refresh(); // ���ο��� Manager.ResolveItem(QuickIndex) + UpdateVisual ȣ��
        }
    }
}

void UQuickSlotBarWidget::BindManagerDelegate()
{
    if (!Manager.IsValid()) return;
    // �ߺ� ���ε� ����
    Manager->OnQuickSlotChanged.RemoveDynamic(this, &UQuickSlotBarWidget::HandleQuickSlotChanged);
    Manager->OnQuickSlotChanged.AddDynamic(this, &UQuickSlotBarWidget::HandleQuickSlotChanged);
}

void UQuickSlotBarWidget::UnbindManagerDelegate()
{
    if (Manager.IsValid())
    {
        Manager->OnQuickSlotChanged.RemoveDynamic(this, &UQuickSlotBarWidget::HandleQuickSlotChanged);
    }
}

void UQuickSlotBarWidget::HandleQuickSlotChanged(int32 SlotIndex, UInventoryItem* Item)
{
    if (SlotIndex < 0 || SlotIndex >= Slots.Num()) return;

    if (UQuickSlotSlotWidget* S = Slots[SlotIndex])
    {
        // ���� �ϳ��� ����
        S->UpdateVisual(Item); // ����(�Ǵ� UpdateVisualBP) ȣ��
    }
}
