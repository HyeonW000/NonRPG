﻿#include "Ability/NonAbilitySystemComponent.h"

UNonAbilitySystemComponent::UNonAbilitySystemComponent()
{
    // 커스텀 설정 필요 시 여기에
}
