#include "Animation/AnimSetTypes.h"
// intentionally empty (struct-only header)
