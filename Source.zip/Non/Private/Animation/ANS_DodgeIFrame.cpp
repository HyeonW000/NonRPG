#include "Animation/ANS_DodgeIFrame.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "GameFramework/Character.h"
#include "GameplayTagContainer.h"
#include "Components/CapsuleComponent.h"
#include "AbilitySystemInterface.h"
#include "AbilitySystemComponent.h"

static FGameplayTag TAG_IFrame = FGameplayTag::RequestGameplayTag(TEXT("State.IFrame"));

void UANS_DodgeIFrame::NotifyBegin(
    USkeletalMeshComponent* MeshComp,
    UAnimSequenceBase* Animation,
    float TotalDuration,
    const FAnimNotifyEventReference& EventReference)
{
    Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);
    if (!MeshComp) return;

    AActor* Owner = MeshComp->GetOwner();
    if (!Owner) return;

    // ĸ�� ��Ȱ�� �ɼ�
    if (bDisablePawnCollision)
    {
        if (ACharacter* C = Cast<ACharacter>(Owner))
        {
            if (UCapsuleComponent* Cap = C->GetCapsuleComponent())
            {
                Cap->SetCollisionEnabled(ECollisionEnabled::NoCollision);
            }
        }
    }

    // ���� ���ѿ����� �±� Add (�������� ������ �����ϹǷ�)
    if (Owner->HasAuthority() && bAddIFrameTag)
    {
        if (IAbilitySystemInterface* Iface = Cast<IAbilitySystemInterface>(Owner))
        {
            if (UAbilitySystemComponent* ASC = Iface->GetAbilitySystemComponent())
            {
                ASC->AddLooseGameplayTag(TAG_IFrame);
            }
        }
    }
}

void UANS_DodgeIFrame::NotifyEnd(
    USkeletalMeshComponent* MeshComp,
    UAnimSequenceBase* Animation,
    const FAnimNotifyEventReference& EventReference)
{
    Super::NotifyEnd(MeshComp, Animation, EventReference);
    if (!MeshComp) return;

    AActor* Owner = MeshComp->GetOwner();
    if (!Owner) return;

    // ĸ�� ����
    if (bDisablePawnCollision)
    {
        if (ACharacter* C = Cast<ACharacter>(Owner))
        {
            if (UCapsuleComponent* Cap = C->GetCapsuleComponent())
            {
                Cap->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
            }
        }
    }

    // ���� ���ѿ����� �±� Remove
    if (Owner->HasAuthority() && bAddIFrameTag)
    {
        if (IAbilitySystemInterface* Iface = Cast<IAbilitySystemInterface>(Owner))
        {
            if (UAbilitySystemComponent* ASC = Iface->GetAbilitySystemComponent())
            {
                ASC->RemoveLooseGameplayTag(TAG_IFrame);
            }
        }
    }
}