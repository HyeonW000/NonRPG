#include "Combat/DamageSphereAOE.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Character.h"

#include "AI/EnemyCharacter.h"
#include "Character/NonCharacterBase.h"

#include "AbilitySystemComponent.h"
#include "GameplayEffect.h"
#include "GameplayTagContainer.h"

ADamageSphereAOE::ADamageSphereAOE()
{
    PrimaryActorTick.bCanEverTick = false;
    bReplicates = true; // ��ġ ����ȭ ������ �ʿ�
    SetReplicateMovement(true);
}

void ADamageSphereAOE::Configure(float InRadius, float InDamage, float InDuration, float InInterval,
    bool bInSingleHit, ETeamSide InTeam, bool bInAttachToSocket,
    FName InSocket, FVector InOffset, bool bInServerOnly)
{
    Radius = InRadius;
    Damage = InDamage;
    Duration = InDuration;
    TickInterval = InInterval;
    bSingleHitPerActor = bInSingleHit;
    Team = InTeam;
    bAttachToOwnerSocket = bInAttachToSocket;
    AttachSocketName = InSocket;
    RelativeOffset = InOffset;
    bServerOnly = bInServerOnly;
}

void ADamageSphereAOE::BeginPlay()
{
    Super::BeginPlay();

    // ���� ���� ó��
    if (bServerOnly && !HasAuthority())
    {
        SetLifeSpan(Duration);
        return;
    }

    // ���� ���󰡱� (Owner�� Mesh/Scene���� ã��)
    if (bAttachToOwnerSocket && GetOwner())
    {
        USceneComponent* Base = nullptr;

        // 1) Enemy/Player Mesh �켱
        if (const ACharacter* C = Cast<ACharacter>(GetOwner()))
        {
            Base = C->GetMesh();
        }
        if (!Base) Base = GetOwner()->GetRootComponent();

        if (Base)
        {
            if (AttachSocketName != NAME_None && Base->DoesSocketExist(AttachSocketName))
            {
                AttachToComponent(Base, FAttachmentTransformRules::KeepWorldTransform, AttachSocketName);
            }
            else
            {
                AttachToComponent(Base, FAttachmentTransformRules::KeepWorldTransform);
            }
            FollowComp = Base;
        }
    }

    // ��� 1ȸ, ���� �ݺ�
    DoHit();
    if (TickInterval > 0.f)
    {
        GetWorldTimerManager().SetTimer(TickTimer, this, &ADamageSphereAOE::DoHit, TickInterval, true);
    }
    SetLifeSpan(Duration);
}

FVector ADamageSphereAOE::ResolveCenter() const
{
    FVector Center = GetActorLocation();
    if (FollowComp.IsValid())
    {
        if (AttachSocketName != NAME_None && FollowComp->DoesSocketExist(AttachSocketName))
        {
            Center = FollowComp->GetSocketLocation(AttachSocketName) + RelativeOffset;
        }
        else
        {
            Center = FollowComp->GetComponentLocation() + RelativeOffset;
        }
    }
    return Center;
}

bool ADamageSphereAOE::IsValidTarget(AActor* Other) const
{
    if (!Other || Other == this || Other == GetOwner()) return false;

    // ���� �� ���� (���ϸ� GameplayTags/Interface�� ��ü)
    switch (Team)
    {
    case ETeamSide::Enemy:
        // ���� ���� �� Ÿ���� �÷��̾�
        if (Cast<ANonCharacterBase>(Other)) return true;
        break;
    case ETeamSide::Player:
        // �÷��̾ ���� �� Ÿ���� ��
        if (Cast<AEnemyCharacter>(Other)) return true;
        break;
    default:
        return true;
    }
    return false;
}

void ADamageSphereAOE::ApplyDamageTo(AActor* Other, const FVector& HitPoint)
{
    // �÷��̾�/�� ����: �� Ŭ������ �̹� ApplyDamageAt(Damage, Instigator, Point) ����
    if (ANonCharacterBase* Player = Cast<ANonCharacterBase>(Other))
    {
        Player->ApplyDamageAt(Damage, GetOwner() ? GetOwner() : this, HitPoint);
        return;
    }
    if (AEnemyCharacter* Enemy = Cast<AEnemyCharacter>(Other))
    {
        Enemy->ApplyDamageAt(Damage, GetOwner() ? GetOwner() : this, HitPoint);
        return;
    }

    // ����: �Ϲ� ����Ʈ ������
    UGameplayStatics::ApplyPointDamage(
        Other, Damage, FVector::UpVector, FHitResult(),
        GetInstigatorController(), GetOwner(), UDamageType::StaticClass());
}

void ADamageSphereAOE::DoHit()
{
    UWorld* World = GetWorld();
    if (!World) return;

    const FVector Center = ResolveCenter();

    // Overlap���� ������! (Pawn/ObjectType ���� �ʿ��ϸ� ����)
    TArray<AActor*> Overlapped;
    TArray<TEnumAsByte<EObjectTypeQuery>> ObjTypes;
    ObjTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_Pawn)); // Pawn �߽�

    TArray<AActor*> Ignore;
    if (AActor* O = GetOwner()) Ignore.Add(O);
    Ignore.Add(this);

    UKismetSystemLibrary::SphereOverlapActors(
        World, Center, Radius, ObjTypes, AActor::StaticClass(), Ignore, Overlapped
    );

    // �����
    if (bDebugDraw)
    {
        DrawDebugSphere(World, Center, Radius, 20, FColor::Red, false, DebugDrawTime, 0, 2.f);
    }

    for (AActor* A : Overlapped)
    {
        if (!IsValidTarget(A)) continue;
        if (bSingleHitPerActor && HitActors.Contains(A)) continue;

        ApplyDamageTo(A, A->GetActorLocation());

        if (bSingleHitPerActor) HitActors.Add(A);
    }
}
