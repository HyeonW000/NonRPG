#include "AI/EnemyCharacter.h"

#include "Ability/NonAbilitySystemComponent.h"
#include "Ability/NonAttributeSet.h"
#include "AbilitySystemComponent.h"
#include "GameplayEffect.h"
#include "GameplayEffectTypes.h"
#include "GameplayTagsManager.h"
#include "GameplayTagContainer.h"

#include "Animation/AnimMontage.h"

#include "UI/EnemyHPBarWidget.h"
#include "Components/WidgetComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/BoxComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Character/NonCharacterBase.h"

#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"

#include "AIController.h"
#include "AI/NonAIController.h"
#include "Animation/EnemyAnimSet.h"
#include "Effects/DamageNumberActor.h"
#include "BrainComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "TimerManager.h"
#include "Engine/World.h"

AEnemyCharacter::AEnemyCharacter()
{
    PrimaryActorTick.bCanEverTick = true;

    AbilitySystemComponent = CreateDefaultSubobject<UNonAbilitySystemComponent>(TEXT("AbilitySystemComponent"));
    AbilitySystemComponent->SetIsReplicated(true);
    AbilitySystemComponent->SetReplicationMode(EGameplayEffectReplicationMode::Mixed);

    AttributeSet = CreateDefaultSubobject<UNonAttributeSet>(TEXT("AttributeSet"));

    // HP Bar
    HPBarWidget = CreateDefaultSubobject<UWidgetComponent>(TEXT("HPBar"));
    if (HPBarWidget)
    {
        HPBarWidget->SetupAttachment(GetMesh());
        HPBarWidget->SetRelativeLocation(FVector(0, 0, 120.f));
        HPBarWidget->SetDrawAtDesiredSize(true);
        HPBarWidget->SetWidgetSpace(EWidgetSpace::Screen);
        HPBarWidget->SetTwoSided(false);
        HPBarWidget->SetPivot(FVector2D(0.5f, 0.5f));
        HPBarWidget->SetDrawSize(FIntPoint(120, 14));
        HPBarWidget->SetVisibility(false);
        HPBarWidget->SetWidgetClass(UEnemyHPBarWidget::StaticClass());
    }

    // �̵�
    bUseControllerRotationYaw = false;
    if (auto* Move = GetCharacterMovement())
    {
        Move->bOrientRotationToMovement = true;
        Move->RotationRate = FRotator(0, 540, 0);
        Move->MaxWalkSpeed = 350.f;
    }

    // ��Ʈ�ڽ� (�⺻ Off, �ִԿ��� On/Off)
    AttackHitbox = CreateDefaultSubobject<UBoxComponent>(TEXT("AttackHitbox"));
    AttackHitbox->SetupAttachment(GetMesh(), TEXT("hand_r")); // �ʿ��� ���ϸ����� ��ü ����
    AttackHitbox->InitBoxExtent(FVector(15.f, 40.f, 40.f));
    AttackHitbox->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
    AttackHitbox->SetCollisionObjectType(ECC_WorldDynamic);
    AttackHitbox->SetCollisionResponseToAllChannels(ECR_Ignore);
    AttackHitbox->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
    AttackHitbox->SetGenerateOverlapEvents(false);

    AttackHitbox->OnComponentBeginOverlap.AddDynamic(this, &AEnemyCharacter::OnAttackHitBegin);

    //Fade
    SpawnFadeDuration = 0.6f;
    bUseSpawnFadeIn = true;
    FadeParamName = TEXT("Fade");
}

UAbilitySystemComponent* AEnemyCharacter::GetAbilitySystemComponent() const
{
    return AbilitySystemComponent;
}

void AEnemyCharacter::BeginPlay()
{
    Super::BeginPlay();

    SpawnLocation = GetActorLocation();

    if (AbilitySystemComponent)
    {
        AbilitySystemComponent->InitAbilityActorInfo(this, this);
    }
    InitializeAttributes();
    BindAttributeDelegates();

    if (HPBarWidget)
    {
        HPBarWidget->InitWidget();
        UpdateHPBar();
        HPBarWidget->SetVisibility(false);
    }

    if (AnimSet)
    {
        if (AnimSet->HitReact_F) HitReact_F = AnimSet->HitReact_F;
        if (AnimSet->HitReact_B) HitReact_B = AnimSet->HitReact_B;
        if (AnimSet->HitReact_L) HitReact_L = AnimSet->HitReact_L;
        if (AnimSet->HitReact_R) HitReact_R = AnimSet->HitReact_R;

        // Death ������ DataAsset �������� �׻� �����
        bUseDeathMontage = AnimSet->bUseDeathMontage;
        DeathMontage = AnimSet->DeathMontage;
    }

    if (bUseSpawnFadeIn)
    {
        InitSpawnFadeMIDs();
        PlaySpawnFadeIn(SpawnFadeDuration);
    }
}

void AEnemyCharacter::Tick(float DeltaSeconds)
{
    Super::Tick(DeltaSeconds);
}

void AEnemyCharacter::InitializeAttributes()
{
    if (AbilitySystemComponent && GE_DefaultAttributes)
    {
        FGameplayEffectContextHandle Ctx = AbilitySystemComponent->MakeEffectContext();
        Ctx.AddSourceObject(this);

        if (FGameplayEffectSpecHandle Spec = AbilitySystemComponent->MakeOutgoingSpec(GE_DefaultAttributes, 1.f, Ctx);
            Spec.IsValid())
        {
            AbilitySystemComponent->ApplyGameplayEffectSpecToSelf(*Spec.Data.Get());
        }
    }
    UpdateHPBar();
}

void AEnemyCharacter::BindAttributeDelegates()
{
    if (!AbilitySystemComponent || !AttributeSet) return;

    AbilitySystemComponent->GetGameplayAttributeValueChangeDelegate(AttributeSet->GetHPAttribute())
        .AddLambda([this](const FOnAttributeChangeData& Data)
            {
                UpdateHPBar();
                UpdateHPBarVisibility();

                if (Data.OldValue > 0.f && Data.NewValue <= 0.f)
                {
                    HandleDeath();
                }
            });
}

void AEnemyCharacter::UpdateHPBar() const
{
    if (!HPBarWidget) return;

    if (UEnemyHPBarWidget* W = Cast<UEnemyHPBarWidget>(HPBarWidget->GetUserWidgetObject()))
    {
        const float Cur = AttributeSet ? AttributeSet->GetHP() : 0.f;
        const float Max = AttributeSet ? AttributeSet->GetMaxHP() : 1.f;
        W->SetHP(Cur, Max);
    }
}

bool AEnemyCharacter::IsDead() const
{
    if (!AttributeSet) return false;
    if (AttributeSet->GetHP() <= 0.f) return true;
    return HasDeadTag();
}

void AEnemyCharacter::HandleDeath()
{
    if (bDied) return;
    bDied = true;

    OnEnemyDied.Broadcast(this);

    if (UCharacterMovementComponent* Move = GetCharacterMovement())
    {
        Move->DisableMovement();
        Move->StopMovementImmediately();
    }
    GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    AddDeadTag();

    if (bUseDeathMontage && DeathMontage && GetMesh())
    {
        const float Len = PlayAnimMontage(DeathMontage, 1.0f);
        if (HPBarWidget) HPBarWidget->SetVisibility(false);
        SetLifeSpan(FMath::Max(1.0f, Len + 0.2f));
        return;
    }

    if (USkeletalMeshComponent* Skel = GetMesh())
    {
        Skel->SetCollisionProfileName(FName("Ragdoll"));
        Skel->SetAllBodiesSimulatePhysics(true);
        Skel->SetSimulatePhysics(true);
        Skel->WakeAllRigidBodies();
    }
    if (HPBarWidget) HPBarWidget->SetVisibility(false);
    SetLifeSpan(5.f);
}

void AEnemyCharacter::ApplyHealthDelta_Direct(float Delta)
{
    if (!AbilitySystemComponent || !AttributeSet) return;

    const float Cur = AttributeSet->GetHP();
    const float Max = AttributeSet->GetMaxHP();
    const float NewVal = FMath::Clamp(Cur + Delta, 0.f, Max);

    AbilitySystemComponent->SetNumericAttributeBase(AttributeSet->GetHPAttribute(), NewVal);
    UpdateHPBar();
}

bool AEnemyCharacter::HasDeadTag() const
{
    if (!AbilitySystemComponent || DeadTagName.IsNone()) return false;
    const FGameplayTag Tag = FGameplayTag::RequestGameplayTag(DeadTagName, false);
    return Tag.IsValid() ? AbilitySystemComponent->HasMatchingGameplayTag(Tag) : false;
}

void AEnemyCharacter::AddDeadTag()
{
    if (!AbilitySystemComponent || DeadTagName.IsNone()) return;
    const FGameplayTag Tag = FGameplayTag::RequestGameplayTag(DeadTagName, false);
    if (Tag.IsValid())
    {
        AbilitySystemComponent->AddLooseGameplayTag(Tag);
    }
}

void AEnemyCharacter::ApplyDamage(float Amount, AActor* DamageInstigator)
{
    EnterCombat();
    ApplyDamageAt(Amount, DamageInstigator, GetActorLocation());
}

void AEnemyCharacter::ApplyDamageAt(float Amount, AActor* DamageInstigator, const FVector& WorldLocation)
{
    if (Amount <= 0.f || !AbilitySystemComponent || !AttributeSet) return;
    if (IsDead()) return;

    // ���� ���� HP ���� (GAS �켱)
    if (GE_Damage)
    {
        FGameplayEffectContextHandle Ctx = AbilitySystemComponent->MakeEffectContext();
        Ctx.AddInstigator(DamageInstigator, Cast<APawn>(DamageInstigator) ? Cast<APawn>(DamageInstigator)->GetController() : nullptr);

        FGameplayEffectSpecHandle Spec = AbilitySystemComponent->MakeOutgoingSpec(GE_Damage, 1.f, Ctx);
        if (Spec.IsValid())
        {
            const FGameplayTag Tag_Damage = FGameplayTag::RequestGameplayTag(TEXT("Data.Damage"));
            Spec.Data->SetSetByCallerMagnitude(Tag_Damage, -Amount);
            AbilitySystemComponent->ApplyGameplayEffectSpecToSelf(*Spec.Data.Get());
        }
    }
    else
    {
        ApplyHealthDelta_Direct(-Amount);
    }

    // ���� ������ ����
    Multicast_SpawnDamageNumber(Amount, WorldLocation, /*bIsCritical=*/false);

    // ���� �ǰ� ���׼�
    OnGotHit(Amount, DamageInstigator, WorldLocation);

    // ���� �� Reactive ��׷�: "�¾Ƽ� ��׷�" �÷��� + Ÿ�ӽ����� ��� ��
    if (AggroStyle == EAggroStyle::Reactive)
    {
        MarkAggroByHit(DamageInstigator);   // bAggroByHit = true, LastAggroByHitTime ������Ʈ
        SetAggro(true);
        UE_LOG(LogTemp, Verbose, TEXT("[Enemy] ApplyDamageAt: Reactive hit �� MarkAggroByHit() & SetAggro(TRUE)"));
    }

    // ���� ���� ����(HP�� ǥ�� ��)
    EnterCombat();
}

void AEnemyCharacter::MarkAggroByHit(AActor* InstigatorActor)
{
    // ���� ���ȴ������� ���� ������ ���⼭ ����/���� ����
    bAggroByHit = true;
    LastAggroByHitTime = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;

    UE_LOG(LogTemp, Verbose, TEXT("[Aggro] MarkAggroByHit by %s (Hold=%.2fs)"),
        *GetNameSafe(InstigatorActor), AggroByHitHoldTime);
}

void AEnemyCharacter::Multicast_SpawnDamageNumber_Implementation(float Amount, FVector WorldLocation, bool bIsCritical)
{
    if (!GetWorld()) return;

    TSubclassOf<ADamageNumberActor> SpawnClass = DamageNumberActorClass;
    if (!SpawnClass) SpawnClass = ADamageNumberActor::StaticClass();

    FActorSpawnParameters SP;
    SP.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
    SP.Owner = this;

     if (ADamageNumberActor* A = GetWorld()->SpawnActor<ADamageNumberActor>(SpawnClass, WorldLocation + FVector(0,0,30), FRotator::ZeroRotator, SP))
    {
        A->InitWithFlags(Amount, bIsCritical);
    }
}

void AEnemyCharacter::EnterCombat()
{
    bInCombat = true;
    UpdateHPBarVisibility();

    GetWorldTimerManager().ClearTimer(CombatTimeoutTimer);
    GetWorldTimerManager().SetTimer(CombatTimeoutTimer, this, &AEnemyCharacter::LeaveCombat, CombatTimeout, false);
}

void AEnemyCharacter::LeaveCombat()
{
    bInCombat = false;
    UpdateHPBarVisibility();
}

void AEnemyCharacter::UpdateHPBarVisibility()
{
    if (!HPBarWidget) return;

    const float Cur = AttributeSet ? AttributeSet->GetHP() : 0.f;
    const float Max = AttributeSet ? AttributeSet->GetMaxHP() : 1.f;

    bool bShouldShow = true;
    if (bShowHPBarOnlyInCombat)
    {
        bShouldShow = bInCombat;
    }
    else
    {
        bShouldShow = (Cur < Max - KINDA_SMALL_NUMBER);
    }
    HPBarWidget->SetVisibility(bShouldShow);
}

void AEnemyCharacter::SetAggro(bool bNewAggro)
{
    bAggro = bNewAggro;
}

void AEnemyCharacter::TryStartAttack()
{
    EnterCombat();

    if (AbilitySystemComponent)
    {
        const FGameplayTag AttackTag = FGameplayTag::RequestGameplayTag(TEXT("Ability.Attack"), false);
        if (AttackTag.IsValid())
        {
            FGameplayTagContainer ActivateTags; ActivateTags.AddTag(AttackTag);
            if (AbilitySystemComponent->TryActivateAbilitiesByTag(ActivateTags))
            {
                return;
            }
        }
    }
    PlayAttackMontage();
}

void AEnemyCharacter::OnGotHit(float Damage, AActor* InstigatorActor, const FVector& ImpactPoint)
{
    ApplyHitStopSelf(0.2f, 0.06f);

    if (!bCanHitReact || IsDead() || Damage <= 0.f)
    {
        return;
    }
    bCanHitReact = false;
    GetWorldTimerManager().SetTimer(HitReactCDTimer, [this]() { bCanHitReact = true; }, HitReactCooldown, false);

    PlayHitReact(ComputeHitQuadrant(ImpactPoint));

    // �ǰ� �˹�(Launch)
    if (KnockbackMode == EKnockbackMode::Launch)
    {
        const FVector Dir = ComputeKnockbackDir(InstigatorActor, ImpactPoint);

        FVector Impulse = Dir * LaunchStrength;

        // Z ������ �ʿ��� ���� �߰� + �������̵�
        const bool bUseZ = FMath::Abs(LaunchUpward) > KINDA_SMALL_NUMBER;
        if (bUseZ)
        {
            Impulse.Z += LaunchUpward;
            LaunchCharacter(Impulse, /*bXYOverride=*/true, /*bZOverride=*/true);
        }
        else
        {
            LaunchCharacter(Impulse, /*bXYOverride=*/true, /*bZOverride=*/false); // �⺻: �� �ȶ�
        }
    }
    // �ǰ� �� ��� �̵� ����
    StartHitMovePause();

    // �ǰ� �� ��� ���� ����
    BlockAttackFor(AttackDelayAfterHit);
}

EHitQuadrant AEnemyCharacter::ComputeHitQuadrant(const FVector& ImpactPoint) const
{
    const FVector Fwd = GetActorForwardVector();
    const FVector Right = GetActorRightVector();
    const FVector ToHit = (ImpactPoint - GetActorLocation()).GetSafeNormal2D();

    const float FwdDot = FVector::DotProduct(Fwd, ToHit);
    const float RightDot = FVector::DotProduct(Right, ToHit);

    if (FMath::Abs(FwdDot) >= FMath::Abs(RightDot))
    {
        return (FwdDot >= 0.f) ? EHitQuadrant::Front : EHitQuadrant::Back;
    }
    else
    {
        return (RightDot >= 0.f) ? EHitQuadrant::Right : EHitQuadrant::Left;
    }
}

void AEnemyCharacter::PlayHitReact(EHitQuadrant Quad)
{
    UAnimMontage* M = nullptr;
    switch (Quad)
    {
    case EHitQuadrant::Front: M = HitReact_F; break;
    case EHitQuadrant::Back:  M = HitReact_B; break;
    case EHitQuadrant::Left:  M = HitReact_L; break;
    case EHitQuadrant::Right: M = HitReact_R; break;
    }
    if (!M) M = HitReact_F;
    if (!M || !GetMesh()) return;

    if (UAnimInstance* Anim = GetMesh()->GetAnimInstance())
    {
        Anim->Montage_Play(M, 1.0f);
    }
}

FVector AEnemyCharacter::ComputeKnockbackDir(AActor* InstigatorActor, const FVector& ImpactPoint) const
{
    // 1) �浹 ���� ����: ImpactPoint -> �� (����)
    if (!ImpactPoint.IsNearlyZero())
    {
        FVector D = (GetActorLocation() - ImpactPoint);
        D.Z = 0.f;
        if (!D.IsNearlyZero()) return D.GetSafeNormal();
    }

    // 2) ������ ����: Instigator -> �� (����)
    if (InstigatorActor)
    {
        FVector D = (GetActorLocation() - InstigatorActor->GetActorLocation());
        D.Z = 0.f;
        if (!D.IsNearlyZero()) return D.GetSafeNormal();
    }

    // 3) ������ ���� �ݴ� ����
    if (const APawn* P = Cast<APawn>(InstigatorActor))
    {
        FVector D = -P->GetActorForwardVector();
        D.Z = 0.f;
        if (!D.IsNearlyZero()) return D.GetSafeNormal();
    }

    // 4) ����: �� ���� �ݴ�
    FVector D = -GetActorForwardVector();
    D.Z = 0.f;
    return D.GetSafeNormal();
}

void AEnemyCharacter::ApplyHitStopSelf(float Scale, float Duration)
{
    Scale = FMath::Clamp(Scale, 0.05f, 1.f);
    CustomTimeDilation = Scale;

    GetWorldTimerManager().ClearTimer(HitStopTimer);
    GetWorldTimerManager().SetTimer(HitStopTimer, [this]()
        {
            CustomTimeDilation = 1.f;
        }, Duration, false);
}

UAnimMontage* AEnemyCharacter::PickAttackMontage() const
{
    if (!AnimSet) return nullptr;
    const TArray<TObjectPtr<UAnimMontage>>& List = AnimSet->AttackMontages;
    if (List.Num() <= 0) return nullptr;

    const int32 Index = FMath::RandRange(0, List.Num() - 1);
    return List[Index];
}

void AEnemyCharacter::PlayAttackMontage()
{
    if (IsDead() || !GetMesh()) return;

    if (UAnimMontage* M = PickAttackMontage())
    {
        if (UAnimInstance* Anim = GetMesh()->GetAnimInstance())
        {
            Anim->Montage_Play(M, 1.0f);
        }
    }
}

void AEnemyCharacter::AttackHitbox_Enable()
{
    // �� ���� ������ ���� �ߺ� Ÿ�� ������
    HitOnce.Reset();

    if (AttackHitbox)
    {
        // �浹 �ѱ� + ������ �̺�Ʈ �ѱ�
        AttackHitbox->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
        AttackHitbox->SetGenerateOverlapEvents(true);

        // (����) ��������Ʈ�� �ߺ����� �ٴ� �� �����Ǹ� �Ʒ� �� �� ���
        // AttackHitbox->OnComponentBeginOverlap.RemoveDynamic(this, &AEnemyCharacter::OnAttackHitBegin);
        // AttackHitbox->OnComponentBeginOverlap.AddDynamic(this, &AEnemyCharacter::OnAttackHitBegin);
    }
}

void AEnemyCharacter::AttackHitbox_Disable()
{
    if (AttackHitbox)
    {
        AttackHitbox->SetGenerateOverlapEvents(false);
        AttackHitbox->SetCollisionEnabled(ECollisionEnabled::NoCollision);

        // (����) �� Enable���� ��������Ʈ�� �ٿ��ٸ� ���⼭ ����
        // AttackHitbox->OnComponentBeginOverlap.RemoveDynamic(this, &AEnemyCharacter::OnAttackHitBegin);
    }

    HitOnce.Reset();
}

void AEnemyCharacter::OnAttackHitBegin(UPrimitiveComponent* Overlapped, AActor* Other,
    UPrimitiveComponent* OtherComp, int32 BodyIndex, bool bFromSweep, const FHitResult& Sweep)
{
    if (!Other || Other == this) return;
    if (HitOnce.Contains(Other)) return;

    // �÷��̾ ���߱�
    if (ANonCharacterBase* Player = Cast<ANonCharacterBase>(Other))
    {
        HitOnce.Add(Other);

        // 1) �⺻ ���� ��ġ �ĺ�
        FVector HitLoc = Sweep.ImpactPoint;

        // 2) Overlap�̸� ImpactPoint�� (0,0,0)�� �� ���� �� Ÿ�� �浹ü���� "���� ����� ��" ����
        if (HitLoc.IsNearlyZero())
        {
            FVector Closest;
            const FVector From = AttackHitbox ? AttackHitbox->GetComponentLocation() : GetActorLocation();

            if (OtherComp && OtherComp->GetClosestPointOnCollision(From, /*out*/Closest))
            {
                HitLoc = Closest;
            }
            else
            {
                // ���� ���н� Ÿ�� �Ӹ�/��ü�� ���� ��ġ ��ó�� ���� ����
                if (USkeletalMeshComponent* Skel = Player->GetMesh())
                {
                    const FName PrefSockets[] = { TEXT("head"), TEXT("spine_03"), TEXT("spine_02"), TEXT("spine_01") };
                    bool bDone = false;
                    for (const FName& S : PrefSockets)
                    {
                        if (Skel->DoesSocketExist(S)) { HitLoc = Skel->GetSocketLocation(S); bDone = true; break; }
                    }
                    if (!bDone) HitLoc = Player->GetActorLocation() + FVector(0,0,90.f);
                }
                else
                {
                    HitLoc = Player->GetActorLocation() + FVector(0,0,90.f);
                }
            }
        }

        // ����� ���
        UE_LOG(LogTemp, Warning, TEXT("[Hitbox] %s -> %s Impact=%s  FromSweep=%d  FinalLoc=%s"),
            *GetName(), *GetNameSafe(Other), *Sweep.ImpactPoint.ToString(), bFromSweep ? 1 : 0, *HitLoc.ToString());
        if (UWorld* W = GetWorld())
        {
            DrawDebugSphere(W, HitLoc, 10.f, 12, FColor::Yellow, false, 2.0f);
        }

        // 3) ���� ������ ����
        const float Damage = 15.f; // TODO: DataAsset/����/���̵��� ����
        Player->ApplyDamageAt(Damage, this, HitLoc);
    }
}

void AEnemyCharacter::BlockAttackFor(float Seconds)
{
    if (UWorld* W = GetWorld())
    {
        NextAttackAllowedTime = FMath::Max(NextAttackAllowedTime, W->GetTimeSeconds() + FMath::Max(0.f, Seconds));
    }
}

bool AEnemyCharacter::IsAttackAllowed() const
{
    if (IsDead()) return false;
    if (const UWorld* W = GetWorld())
    {
        return W->GetTimeSeconds() >= NextAttackAllowedTime;
    }
    return true;
}

void AEnemyCharacter::StartHitMovePause()
{
    if (UCharacterMovementComponent* Move = GetCharacterMovement())
    {
        // ���� �ӵ� ���� ��, ����
        SavedMaxWalkSpeed = Move->MaxWalkSpeed;
        Move->MaxWalkSpeed = SavedMaxWalkSpeed * HitMoveSpeedScale;

        // ���� ���� ���� ���ϸ� ��� ���� + �극��ŷ ��ȭ
        if (HitMoveSpeedScale <= KINDA_SMALL_NUMBER)
        {
            Move->StopMovementImmediately();
            Move->BrakingFrictionFactor = 4.0f; // ��� �޺극��ũ
        }
    }

    // AI �̵��� ��� ����
    if (AAIController* AIC = Cast<AAIController>(GetController()))
    {
        AIC->StopMovement();
    }

    GetWorldTimerManager().ClearTimer(HitMovePauseTimer);
    GetWorldTimerManager().SetTimer(HitMovePauseTimer, this, &AEnemyCharacter::EndHitMovePause, HitMovePauseDuration, false);
}

void AEnemyCharacter::EndHitMovePause()
{
    if (UCharacterMovementComponent* Move = GetCharacterMovement())
    {
        Move->MaxWalkSpeed = (SavedMaxWalkSpeed > 0.f) ? SavedMaxWalkSpeed : Move->MaxWalkSpeed;
        Move->BrakingFrictionFactor = 1.0f; // ����
    }
}

void AEnemyCharacter::MarkEnteredAttackRange()
{
    if (const UWorld* W = GetWorld())
    {
        EnterRangeTime = W->GetTimeSeconds();

        // ���� �ð� ������ ���� ������ �Բ� �ɾ��ָ� �� Ȯ��
        BlockAttackFor(FirstAttackWindup);
    }
}

bool AEnemyCharacter::IsFirstAttackWindupDone() const
{
    if (FirstAttackWindup <= 0.f) return true;       // ������ 0�̸� �׻� ���
    if (EnterRangeTime < 0.f)     return false;      // ��� ���� = ���� ���� ���� ��

    if (const UWorld* W = GetWorld())
    {
        return (W->GetTimeSeconds() - EnterRangeTime) >= FirstAttackWindup;
    }
    return false;
}

//Fade
void AEnemyCharacter::InitSpawnFadeMIDs()
{
    SpawnFadeMIDs.Reset();

    if (USkeletalMeshComponent* Skel = GetMesh())
    {
        const int32 Num = Skel->GetNumMaterials();
        for (int32 i = 0; i < Num; ++i)
        {
            if (UMaterialInterface* Mat = Skel->GetMaterial(i))
            {
                UMaterialInstanceDynamic* MID = UMaterialInstanceDynamic::Create(Mat, this);
                if (MID)
                {
                    MID->SetScalarParameterValue(FadeParamName, 0.0f); // ó���� �� ���̰�
                    Skel->SetMaterial(i, MID);
                    SpawnFadeMIDs.Add(MID);
                }
            }
        }
    }
}

void AEnemyCharacter::PlaySpawnFadeIn(float Duration)
{
    const float UseLen = (Duration > 0.f) ? Duration : SpawnFadeDuration;

    // MID ������ �����ΰ� ���̵尪 0����
    for (UMaterialInstanceDynamic* MID : SpawnFadeMIDs)
    {
        if (MID) MID->SetScalarParameterValue(FadeParamName, 0.0f);
    }

    BeginSpawnFade(UseLen);
}

void AEnemyCharacter::BeginSpawnFade(float DurationSeconds)
{
    SpawnFadeLen = FMath::Max(0.01f, DurationSeconds);
    SpawnFadeStartTime = GetWorld()->GetTimeSeconds();
    bSpawnFadeActive = true;

    if (bPauseAIWhileFading)
    {
        if (UCharacterMovementComponent* Move = GetCharacterMovement())
        {
            SavedMaxWalkSpeed = Move->MaxWalkSpeed;
            Move->DisableMovement();
        }
        if (AAIController* AIC = Cast<AAIController>(GetController()))
        {
            if (UBrainComponent* Brain = AIC->GetBrainComponent())
            {
                Brain->StopLogic(TEXT("SpawnFade"));
            }
        }
    }

    GetWorldTimerManager().ClearTimer(SpawnFadeTimer);
    GetWorldTimerManager().SetTimer(SpawnFadeTimer, this, &AEnemyCharacter::TickSpawnFade, 0.016f, true);
}

void AEnemyCharacter::TickSpawnFade()
{
    if (!bSpawnFadeActive) return;

    const float Now = GetWorld()->GetTimeSeconds();
    float T = (Now - SpawnFadeStartTime) / FMath::Max(0.01f, SpawnFadeLen);
    T = FMath::Clamp(T, 0.f, 1.f);

    // ���̵� �� ����
    for (UMaterialInstanceDynamic* MID : SpawnFadeMIDs)
    {
        if (MID) MID->SetScalarParameterValue(FadeParamName, T);
    }

    if (T >= 1.f)
    {
        bSpawnFadeActive = false;
        OnSpawnFadeFinished();
    }
}

// ���̵� ���� �� �̵�/AI �簳
void AEnemyCharacter::OnSpawnFadeFinished()
{
    GetWorldTimerManager().ClearTimer(SpawnFadeTimer);

    if (UCharacterMovementComponent* Move = GetCharacterMovement())
    {
        Move->SetMovementMode(MOVE_Walking);
        if (SavedMaxWalkSpeed > 0.f)
        {
            Move->MaxWalkSpeed = SavedMaxWalkSpeed;
        }
    }

    if (bAutoResumeAfterFade)
    {
        if (AAIController* AIC = Cast<AAIController>(GetController()))
        {
            if (UBrainComponent* Brain = AIC->GetBrainComponent())
            {
                Brain->StartLogic();
            }
        }
    }
}