#include "AI/NonAIController.h"
#include "BehaviorTree/BlackboardData.h"
#include "Kismet/GameplayStatics.h"

ANonAIController::ANonAIController()
{
    // �ʿ� �� Perception, PathFollowing ���� �߰� ����
}

void ANonAIController::OnPossess(APawn* InPawn)
{
    Super::OnPossess(InPawn);

    UE_LOG(LogTemp, Warning, TEXT("[NonAIController] OnPossess: %s"), *GetNameSafe(InPawn));

    if (!BehaviorTreeAsset)
    {
        UE_LOG(LogTemp, Error, TEXT("[NonAIController] BehaviorTreeAsset is NULL! Set it on BP_NonAIController."));
        return;
    }

    // Blackboard ���
    if (!UseBlackboard(BehaviorTreeAsset->BlackboardAsset, BBComp))
    {
        UE_LOG(LogTemp, Error, TEXT("[NonAIController] UseBlackboard FAILED."));
        return;
    }

    // BT ����
    const bool bRunOk = RunBehaviorTree(BehaviorTreeAsset);
    UE_LOG(LogTemp, Warning, TEXT("[NonAIController] RunBehaviorTree: %s"), bRunOk ? TEXT("OK") : TEXT("FAIL"));

    if (!bRunOk)
    {
        // ���� �ÿ��� �� �� �� �α�
        if (BehaviorTreeAsset->BlackboardAsset == nullptr)
        {
            UE_LOG(LogTemp, Error, TEXT("[NonAIController] BT has NO BlackboardAsset assigned."));
        }
    }
}

void ANonAIController::OnUnPossess()
{
    Super::OnUnPossess();
    UE_LOG(LogTemp, Warning, TEXT("[NonAIController] OnUnPossess"));
}
