#pragma once

#include "CoreMinimal.h"
#include "Engine/DataTable.h"
#include "GameplayTagContainer.h"
#include "NiagaraSystem.h"
#include "Sound/SoundBase.h"
#include "Inventory/ItemEnums.h"
#include "ItemStructs.generated.h"

USTRUCT(BlueprintType)
struct NON_API FEquipmentStatBlock
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadOnly) float AttackPower = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float DefensePower = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float MagicPower = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float MagicResist = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float MoveSpeedBonus = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float CritChance = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float CritDamage = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float CooldownReduction = 0.f;
};

USTRUCT(BlueprintType)
struct NON_API FConsumableEffect
{
    GENERATED_BODY()

    // ��׷�/��Ÿ��
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FName CooldownGroupId;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float CooldownTime = 0.f;

    // ���� ȿ�� ��ø ���?
    UPROPERTY(EditAnywhere, BlueprintReadOnly) bool bAllowStackingEffect = false;

    // ȿ�� �ĺ�(�±�/Id) ? GAS GE/GA ���ο�
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FGameplayTag EffectTag; // ex) Data.Item.Effect.HealInstant
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float EffectValue = 0.f;     // HP+500 ��
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float EffectDuration = 0.f;  // ���� ������ > 0
    UPROPERTY(EditAnywhere, BlueprintReadOnly) bool bRemovesDebuff = false; // ����� ����?
};

USTRUCT(BlueprintType)
struct NON_API FSetBonusEntry
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 PiecesRequired = 2;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FGameplayTag BonusEffectTag; // ex) Data.Item.Set.Bonus.HP
    // �ʿ� �� EffectValue/Duration �� �߰�
};

USTRUCT(BlueprintType)
struct NON_API FItemRow : public FTableRowBase
{
    GENERATED_BODY()

    // ����
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FName ItemId;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FText Name;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FText Description;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) EItemType ItemType = EItemType::Etc;

    // ���� �� ���� ���ϸ� (����θ� ���Ժ� �⺻ ���� �Ǵ� VisualSlots���� ������ ������ ���)
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FName AttachSocket = NAME_None;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) EItemRarity Rarity = EItemRarity::Common;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) TSoftObjectPtr<UTexture2D> Icon;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 MaxStack = 1; // ���=1, �Һ�=99 ��
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 BuyPrice = 0;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 SellPrice = 0;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float DropRate = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) EBindType BindType = EBindType::None;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FGameplayTagContainer CustomTags;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 RequiredLevel = 1; // ����/��� ���� ����

    // ��� ����
    UPROPERTY(EditAnywhere, BlueprintReadOnly) EEquipmentSlot EquipSlot = EEquipmentSlot::None;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) EWeaponType WeaponType = EWeaponType::None;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FEquipmentStatBlock StatBlock;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 EnhancementLevel = 0;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FName SetId; // ��Ʈ �ĺ�
    UPROPERTY(EditAnywhere, BlueprintReadOnly) TArray<FSetBonusEntry> SetBonuses;

    UPROPERTY(EditAnywhere, BlueprintReadOnly) TSoftObjectPtr<USkeletalMesh> SkeletalMesh;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) TSoftObjectPtr<UStaticMesh>   StaticMesh;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) TSoftObjectPtr<UNiagaraSystem> EquipVFX;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) TSoftObjectPtr<USoundBase>    EquipSFX;

    // �Һ� ����
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FConsumableEffect Consumable;

    // ��Ÿ ����
    UPROPERTY(EditAnywhere, BlueprintReadOnly) bool bQuestItem = false;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) bool bTradable = true;   // �ŷ� ���� ����
    UPROPERTY(EditAnywhere, BlueprintReadOnly) bool bNPCShopOnly = false;

};
