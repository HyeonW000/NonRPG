#pragma once

#include "Engine/DataAsset.h"
#include "Animation/BlendSpace.h"
#include "Animation/AnimMontage.h"
#include "EnemyAnimSet.generated.h"

class UAnimSequenceBase;
class UBlendSpace;
class UAnimMontage;

UCLASS(BlueprintType)
class NON_API UEnemyAnimSet : public UDataAsset
{
    GENERATED_BODY()
public:
    // ���ڸ��
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Locomotion")
    TObjectPtr<UBlendSpace> Locomotion = nullptr;

    // ��Ʈ ���׼�(�ڵ忡�� ���)
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HitReact")
    TObjectPtr<UAnimMontage> HitReact_F = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HitReact")
    TObjectPtr<UAnimMontage> HitReact_B = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HitReact")
    TObjectPtr<UAnimMontage> HitReact_L = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HitReact")
    TObjectPtr<UAnimMontage> HitReact_R = nullptr;

    // ���� ��Ÿ�ֵ�(����/�������� ���)
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Attack")
    TArray<TObjectPtr<UAnimMontage>> AttackMontages;

    // ���ݿ� ��� ���� (������ ��Ÿ�� �⺻ ���� ���)
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Attack")
    FName AttackSlotName = NAME_None;

    // ��� ��Ÿ�� �ɼ�
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Death")
    bool bUseDeathMontage = true;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Death", meta = (EditCondition = "bUseDeathMontage"))
    TObjectPtr<UAnimMontage> DeathMontage = nullptr;
};
