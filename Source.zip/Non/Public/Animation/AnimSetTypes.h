#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimMontage.h"
#include "AnimSetTypes.generated.h"

/** ���� ���Ľ� */
UENUM(BlueprintType)
enum class EWeaponStance : uint8
{
    Unarmed,
    OneHanded,
    TwoHanded,
    Staff
};

/** �޺� ���� */
USTRUCT(BlueprintType)
struct FComboAnimSet
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* Combo1 = nullptr;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* Combo2 = nullptr;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* Combo3 = nullptr;
};

/** 8����(0:F,1:FR,2:R,3:BR,4:B,5:BL,6:L,7:FL) */
USTRUCT(BlueprintType)
struct FDirectional8Montages
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* F = nullptr;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* FR = nullptr;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* R = nullptr;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* BR = nullptr;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* B = nullptr;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* BL = nullptr;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* L = nullptr;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* FL = nullptr;

    FORCEINLINE UAnimMontage* GetByIndex(int32 Idx) const
    {
        switch (Idx & 7)
        {
        case 0: return F;   case 1: return FR;  case 2: return R;   case 3: return BR;
        case 4: return B;   case 5: return BL;  case 6: return L;   default: return FL;
        }
    }
};

/** ���� ��Ʈ(���Ľ���) */
USTRUCT(BlueprintType)
struct FWeaponAnimSet
{
    GENERATED_BODY()

    // Draw / Sheathe
    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* Equip = nullptr;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) UAnimMontage* Unequip = nullptr;

    // ����(�޺�)
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Attack")
    FComboAnimSet Attacks;

    // 8���� ȸ��(���⺰)
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Dodge")
    FDirectional8Montages Dodge;

    // ���⺰ ��Ʈ����Ʈ(��/��)
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HitReact")
    UAnimMontage* HitReact_Light = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HitReact")
    UAnimMontage* HitReact_Heavy = nullptr;
};

USTRUCT(BlueprintType)
struct FCommonAnimSet
{
    GENERATED_BODY()

    // ���� ��Ʈ����Ʈ(���⺰ ��Ʈ����Ʈ�� ���� �� ����)
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HitReact")
    UAnimMontage* HitReact_Generic = nullptr;

    // ���� ���� ��Ÿ��
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Death")
    UAnimMontage* DeathMontage = nullptr;

    // (�ʿ��ϸ� Idle/Run �� ���߿� Ȯ�� ����)
};