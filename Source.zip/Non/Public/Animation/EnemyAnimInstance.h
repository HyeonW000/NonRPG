#pragma once

#include "Animation/AnimInstance.h"
#include "Animation/BlendSpace.h"
#include "EnemyAnimInstance.generated.h"

UCLASS(Blueprintable, BlueprintType)
class NON_API UEnemyAnimInstance : public UAnimInstance
{
    GENERATED_BODY()
public:
    virtual void NativeInitializeAnimation() override;
    virtual void NativeUpdateAnimation(float DeltaSeconds) override;

    // AnimGraph/BP���� �о� �� ����
    UPROPERTY(BlueprintReadOnly, Category = "AnimVars", meta = (AllowPrivateAccess = "true"))
    float Speed = 0.f;

    UPROPERTY(BlueprintReadOnly, Category = "AnimVars", meta = (AllowPrivateAccess = "true"))
    bool bInAir = false;

    UPROPERTY(BlueprintReadOnly, Category = "AnimVars", meta = (AllowPrivateAccess = "true"))
    bool bIsAccelerating = false;

    // �׷������� �� ���ڸ�� �����彺���̽� (AnimSet���� ä��)
    UPROPERTY(BlueprintReadOnly, Category = "AnimAssets")
    TObjectPtr<class UBlendSpace>     LocomotionBS = nullptr;

protected:
    TWeakObjectPtr<class ACharacter> OwnerChar;
    TWeakObjectPtr<class UCharacterMovementComponent> MoveComp;

    void PullAnimSetFromOwner();
};
