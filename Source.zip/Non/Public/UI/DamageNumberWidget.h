#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "DamageNumberWidget.generated.h"

class UTextBlock;
class UCanvasPanel;

UCLASS()
class NON_API UDamageNumberWidget : public UUserWidget
{
    GENERATED_BODY()
public:
    virtual void NativeConstruct() override;

    // ǥ���� ����/�� ����
    UFUNCTION(BlueprintCallable, Category = "DamageNumber")
    void SetupNumber(float InValue, const FLinearColor& InColor, int32 InFontSize = 28);

    UFUNCTION(BlueprintCallable, Category = "DamageNumber")
    void SetupLabel(const FText& InText, const FLinearColor& InColor, int32 InFontSize = 28);

    UFUNCTION(BlueprintCallable, Category = "DamageNumber")
    void SetOutline(int32 InSize, FLinearColor InColor);


protected:
    // �ڵ�� ������ �ؽ�Ʈ
    UPROPERTY()
    TObjectPtr<UTextBlock> DamageText = nullptr;

    // ����: �ؽ�Ʈ ����
    void BuildIfNeeded();

    // �ƿ����� ������ BP���� �ٲ� �� �ְ� ����
    UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DamageNumber|Appearance")
    int32 OutlineSize = 2;
    UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DamageNumber|Appearance")
    FLinearColor OutlineColor = FLinearColor::Black;

private:
    float PendingValue = 0.f;
    FLinearColor PendingColor = FLinearColor::White;
    int32 PendingFontSize = 28;
    bool bBuilt = false;
};
