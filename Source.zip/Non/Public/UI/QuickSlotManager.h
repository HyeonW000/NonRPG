// QuickSlotManager.h
#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "QuickSlotManager.generated.h"

class UInventoryComponent;
class UInventoryItem;

USTRUCT(BlueprintType)
struct FQuickSlotEntry
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 SlotIndex = INDEX_NONE; // 0~9
    UPROPERTY(EditAnywhere, BlueprintReadOnly) TWeakObjectPtr<UInventoryComponent> Inventory;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FGuid ItemInstanceId;
    // �� ������ ����Ű�� "������ Ÿ��" (���� 0�̾ ����)
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FName ItemId = NAME_None;

};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnQuickSlotChanged, int32, SlotIndex, UInventoryItem*, Item);


UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class NON_API UQuickSlotManager : public UActorComponent
{
    GENERATED_BODY()
public:
    UQuickSlotManager();

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "QuickSlot")
    int32 NumSlots = 10;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "QuickSlot")
    TArray<FQuickSlotEntry> Slots;

    UPROPERTY(BlueprintAssignable, Category = "QuickSlot")
    FOnQuickSlotChanged OnQuickSlotChanged;

    UFUNCTION(BlueprintCallable, Category = "QuickSlot")
    bool AssignFromInventory(int32 QuickIndex, UInventoryComponent* SourceInv, int32 SourceIdx);

    UFUNCTION(BlueprintCallable, Category = "QuickSlot")
    bool ClearSlot(int32 QuickIndex);

    UFUNCTION(BlueprintCallable, Category = "QuickSlot")
    bool UseQuickSlot(int32 QuickIndex);

    UFUNCTION(BlueprintCallable, Category = "QuickSlot")
    bool SwapSlots(int32 A, int32 B);

    UFUNCTION(BlueprintCallable, Category = "QuickSlot")
    int32 FindSlotByItemId(FName ItemId) const;

    UFUNCTION(BlueprintPure, Category = "QuickSlot")
    UInventoryItem* ResolveItem(int32 QuickIndex) const;

    UFUNCTION(BlueprintCallable, Category = "QuickSlot")
    bool MoveSlot(int32 SourceIndex, int32 DestIndex);

    // �� �߰�: �ش� ���� �������� "�κ��丮 ��ü �Ѽ���" ��ȯ
    UFUNCTION(BlueprintPure, Category = "QuickSlot")
    int32 GetTotalCountForSlot(int32 QuickIndex) const;

    UFUNCTION(BlueprintPure, Category = "QuickSlot")
    bool IsSlotAssigned(int32 QuickIndex) const;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QuickSlot|Filter")
    bool bAllowConsumables = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QuickSlot|Filter")
    bool bAllowQuestItems = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QuickSlot|Filter")
    bool bAllowSkills = true;

    // ���� üũ�Լ�
    bool IsAllowedForQuickslot(const UInventoryItem* Item) const;

protected:
    virtual void BeginPlay() override;

    UInventoryItem* FindItemByInstance(UInventoryComponent* Inv, const FGuid& InstanceId) const;

    // �κ��丮 ������ ������ ����Ʈ/����ε� �ݿ�
    void EnsureInventoryObserved(UInventoryComponent* Inv);
    UFUNCTION() void OnInventorySlotUpdated(int32 UpdatedIndex, UInventoryItem* UpdatedItem);
    UFUNCTION() void OnInventoryRefreshed();

private:
    // ���� ���� �κ��丮 ����(�ߺ� ���ε� ����)
    UPROPERTY() TSet<TWeakObjectPtr<UInventoryComponent>> ObservedInventories;

    TSet<TWeakObjectPtr<UInventoryComponent>> Observed;

};
