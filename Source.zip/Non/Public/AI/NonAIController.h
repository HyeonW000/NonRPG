#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "NonAIController.generated.h"

UCLASS()
class NON_API ANonAIController : public AAIController
{
    GENERATED_BODY()
public:
    ANonAIController();

    // �����Ϳ��� BP_NonAIController�� ���� BT �ڻ�
    UPROPERTY(EditDefaultsOnly, Category = "AI")
    UBehaviorTree* BehaviorTreeAsset = nullptr;

protected:
    virtual void OnPossess(APawn* InPawn) override;
    virtual void OnUnPossess() override;

private:
    UPROPERTY()
    UBlackboardComponent* BBComp = nullptr;
};
